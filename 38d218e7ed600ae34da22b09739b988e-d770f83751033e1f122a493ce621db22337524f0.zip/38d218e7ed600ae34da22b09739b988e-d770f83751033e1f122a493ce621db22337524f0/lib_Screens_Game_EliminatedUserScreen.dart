import 'package:flutter/material.dart';

class eliminatedUser extends StatefulWidget {
  @override
  _eliminatedUserState createState() => _eliminatedUserState();
}

class _eliminatedUserState extends State<eliminatedUser> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
