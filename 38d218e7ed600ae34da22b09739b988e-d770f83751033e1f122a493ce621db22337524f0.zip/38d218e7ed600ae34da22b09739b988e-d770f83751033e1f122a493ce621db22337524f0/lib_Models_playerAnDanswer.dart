

class PlayerAndAnswer {
  final String uid;
  final String answer;
  final String pp;

  PlayerAndAnswer({this.uid,this.answer,this.pp});

  void eliminateuser(){
    print('user eliminated');
  }



}